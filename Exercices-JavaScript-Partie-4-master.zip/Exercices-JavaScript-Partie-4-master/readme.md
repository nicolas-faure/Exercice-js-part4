## Javascript - Partie 4
**Important**  
Il faut lancer le fichier SpecRunner.html pour valider ses réponses.  
Les réponses seront à écrire dans le fichier questions.js
