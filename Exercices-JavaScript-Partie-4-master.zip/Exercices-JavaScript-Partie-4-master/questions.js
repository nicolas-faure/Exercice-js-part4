/**
 * Exercice sur les chaines de caractères.
 * Trouvez la façon de faire la plus optimal.
 * Il peut y avoir plusieur façon de faire. 
 */
var tailleString = function (texte) {
    return 'A completer';
}
var remplaceECar = function (texte) {
    return 'A completer';
}
var concatString = function (texte1, texte2) {
    return 'A completer';
}
var afficherCar5 = function (texte) {
    return 'A completer';
}
var afficher9Car = function (texte) {
    return 'A completer';
}
var majusculeString = function (texte) {
    return 'A completer';
}
var minusculeString = function (texte) {
    return 'A completer';
}
var SupprEspaceString = function (texte) {
    return 'A completer';
}
var IsString = function (texte) {
    return 'A completer';
}
var AfficherExtensionString = function (texte) {
    return 'A completer';
}
var NombreEspaceString = function (texte) {
    return 'A completer';
}
var InverseString = function (texte) {
    return 'A completer';
}

/**
 * Exercices sur les nombres et les caluls mathématiques
 */
var calculPuissance = function (x, y) {
    return 'A completer';
}
var valeurAbsolue = function (nombre) {
    return 'A completer';
}
var valeurAbsolueArray = function (array) {
    return 'A completer';
}
var sufaceCercle = function (rayon) {
    return 'A completer';
}
var hypothenuse = function (ab, ac) {
    return 'A completer';
}
var calculIMC = function (poids, taille) {
    return 'A completer';
}